function openTab(evt, cityName) {
		var i, tabcontent, tablinks;
		tabcontent = document.getElementsByClassName("tabcontent");
		for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
		}
		tablinks = document.getElementsByClassName("tablinks");
		for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
		}
		document.getElementById(cityName).style.display = "block";
		evt.currentTarget.className += " active";
		}
window.onload = function () {
  startTab();
  openpage();
		};
function startTab() {
  document.getElementById("defaultOpen").click();
  }
  function openpage(){
  	document.getElementById("section1id").classList.add("xtra");
  }
let rightselect=document.getElementsByClassName("P-upperrightAdd3");
	console.log(rightselect)
	for(let i = 0 ; i < rightselect.length ; i++ ){
		let mk=rightselect[i];
		mk.addEventListener('click', function(){
			let s1=document.getElementById("section4id");
			let s2=document.getElementById("section3id");
			console.log(s1)
			console.log(s2)

			if(s2.classList.contains("ccc")){
				s2.classList.remove("ccc");
				s1.classList.add("up4");
			}
		})
	}
let leftselect = document.getElementsByClassName("P-upperleftAdd3");
	console.log(leftselect);
	for( i=0 ; i<leftselect.length; i++){
		let lk=leftselect[i];
		lk.addEventListener('click',function(){
			let m1=document.getElementById("section5id");
			let m2=document.getElementById("section3id");
			console.log(m1)
			console.log(m2)
			if(m2.classList.contains("ccc")){
				m2.classList.remove("ccc");
				m1.classList.add("up5");
			}
		})
	}
let section1Rclick= document.getElementsByClassName("P-rightAdd");
console.log(section1Rclick);
for( i=0;i<section1Rclick.length;i++){
	let opensection1=section1Rclick[i]
	opensection1.addEventListener('click',function(){
		let n1=document.getElementById("section1id");
		let n2=document.getElementById("section2id");
		console.log(n1);
		console.log(n2);
		if(n1.classList.contains("section1")){
			n1.classList.remove("section1");
			n1.classList.add("unmove");
			n2.classList.add("move");
		}
	})
}
let section1Lclick= document.getElementsByClassName("P-leftAdd");
console.log(section1Lclick);
for( i=0;i<section1Lclick.length;i++){
	let opensection2=section1Lclick[i]
	opensection2.addEventListener('click',function(){
		let n1=document.getElementById("section1id");
		let n2=document.getElementById("section2id");
		console.log(n1);
		console.log(n2);
		if(n1.classList.contains("section1")){
			n1.classList.remove("section1");
			n1.classList.add("unmove");
			n2.classList.add("move");
		}
	})
}
function apply(){
let x1=document.getElementById("section2id");
let y2=document.getElementById("section3id");
x1.classList.add("bbb");
y2.classList.add("ccc");
console.log("apply clicked");
 }
let section2Back=document.getElementsByClassName("P-btn1");
console.log(section2Back)
for( i=0;i<section2Back.length;i++){
	let goBack=section2Back[i]
	goBack.addEventListener('click',function(){
		let o1=document.getElementById("section1id");
		let o2=document.getElementById("section2id");
		console.log(o1);
		console.log(o2);
		if(o1.classList.contains("unmove")){
			o1.classList.remove("unmove");
			o1.classList.add("section1");
			o2.classList.remove("move");
		}
	})
}
let section3Back=document.getElementsByClassName("P-btn1third");
console.log(section3Back)
for( i=0;i<section3Back.length;i++){
	let goBack3sec=section3Back[i]
	goBack3sec.addEventListener('click',function(){
		let o1=document.getElementById("section2id");
		let o2=document.getElementById("section3id");
		console.log(o1);
		console.log(o2);
		console.log("clicked back button")
		if(o2.classList.contains("ccc")){
			o2.classList.remove("ccc");
			o1.classList.remove("bbb");
		}
	})
}
let goBackfivesec=document.getElementsByClassName("P-btn1thirdfive");
for( i=0 ; i < goBackfivesec.length ; i++){
	let sec5back=goBackfivesec[i];
	sec5back.addEventListener('click',function(){
		let bata1=document.getElementById("section5id");
		let bata2=document.getElementById("section3id");
		console.log(bata1);
		console.log(bata2);
		if(bata1.classList.contains("up5")){
			bata1.classList.remove("up5");
			bata2.classList.add("ccc");
		}
	})

}
let goBack4sec=document.getElementsByClassName("P-btn1thirdfour");
for( i=0 ; i < goBack4sec.length;i++){
	let sec4back=goBack4sec[i];
	sec4back.addEventListener('click',function(){
		let run1=document.getElementById("section4id");
		let run2=document.getElementById("section3id");
		console.log(run1);
		console.log(run2);
		if(run1.classList.contains("up4")){
			run1.classList.remove("up4");
			run2.classList.add("ccc");
		}
	})
}
let goright2to=document.getElementsByClassName("P-upperrightAdd3five");
for( i=0; i < goright2to.length ; i++ ){
	let secto2back=goright2to[i];
	secto2back.addEventListener('click',function(){
		let bounce1=document.getElementById("section5id");
		let bounce2=document.getElementById("section2id");
		if(bounce1.classList.contains("up5")){
			bounce1.classList.remove("up5");
			bounce2.classList.remove("bbb");

			document.getElementById("int1").value="";
			document.getElementById("int2").value="";
			document.getElementById("int3").value="";
			document.getElementById("input1").innerHTML="";
			document.getElementById("input2").innerHTML="";
			document.getElementById("input3").innerHTML="";
			document.getElementById("P-fontInput").value="";
			document.getElementById("P-colorInput").value="";
			document.getElementById("P-sizeInput").value="";
			document.getElementById("P-imageInput").value="";
			document.getElementById("P-imageInput").value="";
			console.log("sec5  clicked back to sec2 right");
			// bounce2.classList.add("move");
		}
	})
}
let goleft2to=document.getElementsByClassName("P-upperleftAdd3four");
for( i=0;i<goleft2to.length ; i++){
	let secleft2back=goleft2to[i];
	secleft2back.addEventListener('click',function(){
		let jack1=document.getElementById("section4id");
		let jack2=document.getElementById("section2id");
		let jack3=document.getElementById("section3id");
		if(jack1.classList.contains("up4")){
			jack1.classList.remove("up4");
			jack3.classList.remove("ccc");
			jack2.classList.remove("bbb");

			// document.getElementByid("upperRid").innerHTML="upper left chest ";
			document.getElementById("int1").value="";
			document.getElementById("int2").value="";
			document.getElementById("int3").value="";
			document.getElementById("input1").innerHTML="";
			document.getElementById("input2").innerHTML="";
			document.getElementById("input3").innerHTML="";
			document.getElementById("P-fontInput").value="";
			document.getElementById("P-colorInput").value="";
			document.getElementById("P-sizeInput").value="";
			document.getElementById("P-imageInput").value="";
			document.getElementById("P-imageInput").value="";
			
			console.log("sec5  clicked back to sec2 left");
		}
	})
}

let d1=document.getElementById("int1");
let d2=document.getElementById("input1");

let zz1=document.getElementById("input11");
d1.addEventListener('input',function(){
	d2.innerHTML=d1.value;
	zz1.innerHTML=d1.value;
	zz2.innerHTML=d1.value;
	zz3.innerHTML=d1.value;
	zl1.innerHTML=d1.value;
})
let d3=document.getElementById("int2");
let d4=document.getElementById("input2");
d3.addEventListener('input',function(){
	d4.innerHTML=d3.value;
})
let d5=document.getElementById("int3");
let d6=document.getElementById("input3");
d5.addEventListener('input',function(){
	d6.innerHTML=d5.value;
})
document.getElementById("resetId").addEventListener('click',function(){
	document.getElementById("int1").value="";
	document.getElementById("int2").value="";
	document.getElementById("int3").value="";
	document.getElementById("input1").innerHTML="";
	document.getElementById("input2").innerHTML="";
	document.getElementById("input3").innerHTML="";
	document.getElementById("P-fontInput").value="";
	document.getElementById("P-colorInput").value="";
	document.getElementById("P-sizeInput").value="";
	document.getElementById("P-imageInput").value="";
	document.getElementById("newimglogo").src="";
	document.getElementById("P-imageInput").value="";
	console.log("reset clicked");
})

let zz=document.getElementById("input1");
// let zz1=document.getElementById("input11");
let zz2=document.getElementById("input111");
let zz3=document.getElementById("input1111");

let zl1=document.getElementById("inputL1");

let copyff=document.getElementById("P-fontInput");

let fontz=document.getElementById("infospanright1");
let fontz1=document.getElementById("infospanright2");
let fontz11=document.getElementById("infospanright3");

let fontL=document.getElementById("infospanleft1");
let fontL1=document.getElementById("infospanleft2");
let fontL11=document.getElementById("infospanleft3");

let fontz2=document.getElementById("infospanright1four");
let fontz22=document.getElementById("infospanright2four");
let fontz222=document.getElementById("infospanright3four");

let f5span=document.getElementById("infospanleft1five");
let f55span=document.getElementById("infospanleft2five");
let f555span=document.getElementById("infospanleft3five");



	let smallf1=document.getElementById("smallF1");
	let fPalatino=document.getElementById("fontPalatino");
	fPalatino.addEventListener('click',function(){
		zz.style.fontFamily="palatino";
		zz1.style.fontFamily="palitino";
		zz2.style.fontFamily="palitino";
		zz3.style.fontFamily="palitino";
		zl1.style.fontFamily="palitino";
		copyff.value=smallf1.innerHTML;
		fontz.innerHTML=smallf1.innerHTML;
		fontz2.innerHTML=smallf1.innerHTML;
		fontL.innerHTML=smallf1.innerHTML;
		f5span.innerHTML=smallf1.innerHTML;
})
	let smallf2=document.getElementById("smallF2");
	let fImpact=document.getElementById("fontImpact");
	fImpact.addEventListener('click',function(){
		zz.style.fontFamily="impact";
		zz1.style.fontFamily="impact";
		zz2.style.fontFamily="impact";
		zz3.style.fontFamily="impact";
		zl1.style.fontFamily="impact";
		copyff.value=smallf2.innerHTML;
		fontz.innerHTML=smallf2.innerHTML;
		fontz2.innerHTML=smallf2.innerHTML;
		fontL.innerHTML=smallf2.innerHTML;
		f5span.innerHTML=smallf2.innerHTML;
})

	let smallf3=document.getElementById("smallF3");
	let fGeorgia=document.getElementById("fontGeorgia");
	fGeorgia.addEventListener('click',function(){
		zz.style.fontFamily="georgia";
		zz1.style.fontFamily="georgia";
		zz2.style.fontFamily="georgia";
		zz3.style.fontFamily="georgia";
		zl1.style.fontFamily="georgia";
		copyff.value=smallf3.innerHTML;
		fontz.innerHTML=smallf3.innerHTML;
		fontz2.innerHTML=smallf3.innerHTML;
		fontL.innerHTML=smallf3.innerHTML;
		f5span.innerHTML=smallf3.innerHTML;
})
	let smallf4=document.getElementById("smallF4");
	let fVerdana=document.getElementById("fontVerdana");
	fVerdana.addEventListener('click',function(){
		zz.style.fontFamily="verdana";
		zz1.style.fontFamily="verdana";
		zz2.style.fontFamily="verdana";
		zz3.style.fontFamily="verdana";
		zl1.style.fontFamily="verdana";
		copyff.value=smallf4.innerHTML;
		fontz.innerHTML=smallf4.innerHTML;
		fontz2.innerHTML=smallf4.innerHTML;
		fontL.innerHTML=smallf4.innerHTML;
		f5span.innerHTML=smallf4.innerHTML;
})
	let smallf5=document.getElementById("smallF5");
	let fCourier=document.getElementById("fontCourier");
	fCourier.addEventListener('click',function(){
		zz.style.fontFamily="courier";
		zz1.style.fontFamily="courier";
		zz2.style.fontFamily="courier";
		zz3.style.fontFamily="courier";
		zl1.style.fontFamily="courier";
		copyff.value=smallf5.innerHTML;
		fontz.innerHTML=smallf5.innerHTML;
		fontz2.innerHTML=smallf5.innerHTML;
		fontL.innerHTML=smallf5.innerHTML;
		f5span.innerHTML=smallf5.innerHTML;
})
	let smallf6=document.getElementById("smallF6");
	let fHelvetica=document.getElementById("fontHelvetica");
	fHelvetica.addEventListener('click',function(){
		zz.style.fontFamily="helvetica";
		zz1.style.fontFamily="helvetica";
		zz2.style.fontFamily="helvetica";
		zz3.style.fontFamily="helvetica";
		zl1.style.fontFamily="helvetica";
		copyff.value=smallf6.innerHTML;
		fontz.innerHTML=smallf6.innerHTML;
		fontz2.innerHTML=smallf6.innerHTML;
		fontL.innerHTML=smallf6.innerHTML;
		f5span.innerHTML=smallf6.innerHTML;
})
	let smallf7=document.getElementById("smallF7");
	let fSerif=document.getElementById("fontSerif");
	fSerif.addEventListener('click',function(){
		zz.style.fontFamily="serif";
		zz1.style.fontFamily="serif";
		zz2.style.fontFamily="serif";
		zz3.style.fontFamily="serif";
		zl1.style.fontFamily="serif";
		copyff.value=smallf7.innerHTML;
		fontz.innerHTML=smallf7.innerHTML;
		fontz2.innerHTML=smallf7.innerHTML;
		fontL.innerHTML=smallf7.innerHTML;
		f5span.innerHTML=smallf7.innerHTML;
})

	let yy=document.getElementById("P-sizeInput");

	let sizef1=document.getElementById("sizeF1");
	let z12=document.getElementById("get12");
	z12.addEventListener('click',function(){
		console.log("12px clicked");
		zz.style.fontSize='12px';
		zz1.style.fontSize='12px';
		zz2.style.fontSize='12px';
		zz3.style.fontSize='12px';
		zl1.style.fontSize='12px';
		yy.value=sizef1.innerHTML;
		fontz1.innerHTML=sizef1.innerHTML;
		fontz22.innerHTML=sizef1.innerHTML;
		fontL1.innerHTML=sizef1.innerHTML;
		f55span.innerHTML=sizef1.innerHTML;

})
	let sizef2=document.getElementById("sizeF2");
	let z14=document.getElementById("get14");
	z14.addEventListener('click',function(){
		console.log("14px clicked");
		zz.style.fontSize='14px';
		zz1.style.fontSize='14px';
		zz2.style.fontSize='14px';
		zz3.style.fontSize='14px';
		zl1.style.fontSize='14px';
		yy.value=sizef2.innerHTML;
		fontz1.innerHTML=sizef2.innerHTML;
		fontz22.innerHTML=sizef2.innerHTML;
		fontL1.innerHTML=sizef2.innerHTML;
		f55span.innerHTML=sizef2.innerHTML;
})
	let sizef3=document.getElementById("sizeF3");
	let z16=document.getElementById("get16");
	z16.addEventListener('click',function(){
		console.log("16px clicked");
		zz.style.fontSize='16px';
		zz1.style.fontSize='16px';
		zz2.style.fontSize='16px';
		zz3.style.fontSize='16px';
		zl1.style.fontSize='16px';
		yy.value=sizef3.innerHTML;
		fontz1.innerHTML=sizef3.innerHTML;
		fontz22.innerHTML=sizef3.innerHTML;
		fontL1.innerHTML=sizef3.innerHTML;
		f55span.innerHTML=sizef3.innerHTML;
})
	let sizef4=document.getElementById("sizeF4");
	let z18=document.getElementById("get18");
	z18.addEventListener('click',function(){
		console.log("18px clicked");
		zz.style.fontSize='18px';
		zz1.style.fontSize='18px';
		zz2.style.fontSize='18px';
		zz3.style.fontSize='18px';
		zl1.style.fontSize='18px';
		yy.value=sizef4.innerHTML;
		fontz1.innerHTML=sizef4.innerHTML;
		fontz22.innerHTML=sizef4.innerHTML;
		fontL1.innerHTML=sizef4.innerHTML;
		f55span.innerHTML=sizef4.innerHTML;
})
	let sizef5=document.getElementById("sizeF5");
	let z20=document.getElementById("get20");
	z20.addEventListener('click',function(){
		console.log("20px clicked");
		zz.style.fontSize='20px';
		zz1.style.fontSize='20px';
		zz2.style.fontSize='20px';
		zz3.style.fontSize='20px';
		zl1.style.fontSize='20px';
		yy.value=sizef5.innerHTML;
		fontz1.innerHTML=sizef5.innerHTML;
		fontz22.innerHTML=sizef5.innerHTML;
		fontL1.innerHTML=sizef5.innerHTML;
		f55span.innerHTML=sizef5.innerHTML;
})
	let coll=document.getElementById("P-colorInput");

	let small1col=document.getElementById("smallBlue");
	let colBlue=document.getElementById("colBlue");
	colBlue.addEventListener('click',function(){
		console.log("blue clicked");
		zz.style.color="blue";
		zz1.style.color="blue";
		zz2.style.color="blue";
		zz3.style.color="blue";
		zl1.style.color="blue";
		coll.value=small1col.innerHTML;
		fontz11.innerHTML=small1col.innerHTML;
		fontz222.innerHTML=small1col.innerHTML;
		fontL11.innerHTML=small1col.innerHTML;
		f555span.innerHTML=small1col.innerHTML;

})
	let small2col=document.getElementById("smallYellow");
	let colYellow=document.getElementById("colYellow");
	colYellow.addEventListener('click',function(){
		console.log("yellow clicked");
		zz.style.color="yellow";
		zz1.style.color="yellow";
		zz2.style.color="yellow";
		zz3.style.color="yellow";
		zl1.style.color="yellow";
		coll.value=small2col.innerHTML;
		fontz11.innerHTML=small2col.innerHTML;
		fontz222.innerHTML=small2col.innerHTML;
		fontL11.innerHTML=small2col.innerHTML;
		f555span.innerHTML=small2col.innerHTML;
		})
	let small3col=document.getElementById("smallGreen");
	let colGreen=document.getElementById("colGreen");
	colGreen.addEventListener('click',function(){
		console.log("Green clicked");
		zz.style.color="green";
		zz1.style.color="green";
		zz2.style.color="green";
		zz3.style.color="green";
		zl1.style.color="green";
		coll.value=small3col.innerHTML;
		fontz11.innerHTML=small3col.innerHTML;
		fontz222.innerHTML=small3col.innerHTML;
		fontL11.innerHTML=small3col.innerHTML;
		f555span.innerHTML=small3col.innerHTML;
		})
	let small4col=document.getElementById("smallBlack");
	let colBlack=document.getElementById("colBlack");
	colBlack.addEventListener('click',function(){
		console.log("Black clicked");
		zz.style.color="black";
		zz1.style.color="black";
		zz2.style.color="black";
		zz3.style.color="black";
		zl1.style.color="black";
		coll.value=small4col.innerHTML;
		fontz11.innerHTML=small4col.innerHTML;
		fontz222.innerHTML=small4col.innerHTML;
		fontL11.innerHTML=small4col.innerHTML;
		f555span.innerHTML=small4col.innerHTML;
		})
	let small5col=document.getElementById("smallWhite");
	let colWhite=document.getElementById("colWhite");
	colWhite.addEventListener('click',function(){
		console.log("White clicked");
		zz.style.color="white";
		zz1.style.color="white";
		zz2.style.color="white";
		zz3.style.color="white";
		zl1.style.color="white";
		coll.value=small5col.innerHTML;
		fontz11.innerHTML=small5col.innerHTML;
		fontz222.innerHTML=small5col.innerHTML;
		fontL11.innerHTML=small5col.innerHTML;
		f555span.innerHTML=small5col.innerHTML;
		})

let nike1=document.getElementById("imgclick1");
let nike2=document.getElementById("imgclick2");
let nike3=document.getElementById("imgclick3");
let nike4=document.getElementById("imgclick4");

let srcimage1=document.getElementById("logoimg1").src;
let srcimage2=document.getElementById("logoimg2").src;
let srcimage3=document.getElementById("logoimg3").src;
let srcimage4=document.getElementById("logoimg4").src;

nike1.addEventListener('click',function(){
	document.getElementById("newimglogo").src=srcimage1;
	document.getElementById("sect3imgright").src=srcimage1;
	document.getElementById("sect3imgleft").src=srcimage1;
	document.getElementById("sect4imgright").src=srcimage1;
	document.getElementById("sect5imgleft").src=srcimage1;
	document.getElementById("P-imageInput").value=document.getElementById("imgdoc1").innerHTML;
	console.log("img1 clicked");
})
nike2.addEventListener('click',function(){
	document.getElementById("newimglogo").src=srcimage2;
	document.getElementById("sect3imgright").src=srcimage2;
	document.getElementById("sect3imgleft").src=srcimage2;
	document.getElementById("sect4imgright").src=srcimage2;
	document.getElementById("sect5imgleft").src=srcimage2;
	document.getElementById("P-imageInput").value=document.getElementById("imgdoc2").innerHTML;
	console.log("img2 clicked");	
})
nike3.addEventListener('click',function(){
	document.getElementById("newimglogo").src=srcimage3;
	document.getElementById("sect3imgright").src=srcimage3;
	document.getElementById("sect3imgleft").src=srcimage3;
	document.getElementById("sect4imgright").src=srcimage3;
	document.getElementById("sect5imgleft").src=srcimage3;
	document.getElementById("P-imageInput").value=document.getElementById("imgdoc3").innerHTML;
	console.log("img3 clicked");
})
nike4.addEventListener('click',function(){
	document.getElementById("newimglogo").src=srcimage4;
	document.getElementById("sect3imgright").src=srcimage4;
	document.getElementById("sect3imgleft").src=srcimage4;
	document.getElementById("sect4imgright").src=srcimage4;
	document.getElementById("sect5imgleft").src=srcimage4;
	document.getElementById("P-imageInput").value=document.getElementById("imgdoc4").innerHTML;
	console.log("img4 clicked");
})
